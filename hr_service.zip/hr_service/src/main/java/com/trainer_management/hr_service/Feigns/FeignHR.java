package com.trainer_management.hr_service.Feigns;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.trainer_management.hr_service.model.CohortDTO;

@FeignClient("JWT")
public interface FeignHR {
	
	
	@PostMapping("/validatehr")
	public boolean validatehr(@RequestBody CohortDTO c);
	
}
