package com.trainer_management.hr_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainer_management.hr_service.Feigns.TrainerFeign;
import com.trainer_management.hr_service.model.TrainerDTO;
import com.trainer_management.hr_service.model.TrainerInfo;

@Service
public class TrainerService {
	
	
	
	private TrainerFeign tf;
	public TrainerService(TrainerFeign tf) {
		this.tf=tf;
	}
	
	
	
	public String registerTrainer(TrainerInfo td) {
		return tf.registerTrainer(td);
	}
	
	
	public ResponseEntity<String> deleteTrainer(String id) {
		return ResponseEntity.ok(tf.deleteTrainer(id));
	}
	
	
	public ResponseEntity<String> searchTrainer(String id) {
		return ResponseEntity.ok(tf.searchTrainer(id));
	}
	
	public ResponseEntity<List<TrainerInfo>> searchTrainers( String name,
			 Integer minExp,
			 Integer maxExp,
			 String mappedType,
			 String role,
			 String gender,
			 List<String> skills){
		return ResponseEntity.ok(tf.searchTrainers(name,minExp,maxExp,mappedType,role,gender,skills));
	}
	
	
	 public List<TrainerInfo> getAllTrainers() {
	        return tf.findAll();
	    }
	
}
