package com.trainer_management.hr_service.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.eclipse.angus.mail.iap.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.trainer_management.hr_service.Feigns.FeignHR;
import com.trainer_management.hr_service.Feigns.TrainerFeign;
import com.trainer_management.hr_service.model.Allocation;
import com.trainer_management.hr_service.model.AllocationDTO;
import com.trainer_management.hr_service.model.CohortDTO;
import com.trainer_management.hr_service.model.PK;
import com.trainer_management.hr_service.repository.AllocationDAO;
import com.trainer_management.hr_service.repository.CohortDAO;

@Service
public class CohortService {
	private CohortDAO cd;
	private AllocationDAO adao;
	private TrainerFeign tf;
	private FeignHR th;
	
	public CohortService(CohortDAO cd, AllocationDAO adao, TrainerFeign tf,FeignHR th) {
		super();
		this.cd = cd;
		this.adao=adao;
		this.tf=tf;
		this.th=th;
	}
	
	
	public ResponseEntity<String> addCohort(CohortDTO c){
		if(th.validatehr(c) == false){
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(c.getHr_id()+" do not exists");
		}
		
		if(cd.existsById(c.getCohortCode())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Cohort "+ c.getCohortCode()+" already exists");
		}
		
		cd.save(c);
		
		 
		 return ResponseEntity.ok(c.toString());
	}
    public ResponseEntity<String> deleteCohort(String cohortCode){
    	Optional<CohortDTO>  optCoh=cd.findById(cohortCode);
    	if(optCoh==null) return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("cohort code is not avaliable");
    	CohortDTO c=optCoh.get();
    	cd.delete(c);
    	return ResponseEntity.ok("deleted successfully");
    	
    }
	public ResponseEntity<CohortDTO> searchCohort(String cohortCode) {
		Optional<CohortDTO>  optCoh=cd.findById(cohortCode);
		CohortDTO c=optCoh.orElse(new CohortDTO());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(c);
	}
	public ResponseEntity<String> allocate(AllocationDTO ad){
		
		System.out.println(ad.toString());
		if(cd.findById(ad.getCohortCode()).isPresent() ) {
			Object result=tf.findById(ad.getId());
			System.out.println(result.getClass().getName());
			
			if(Boolean.TRUE.equals(result)) {
				PK primaryKey=new PK(ad.getCohortCode(),ad.getId());
				Allocation a=new Allocation(primaryKey,ad.getAreaWork());
				adao.save(a);
				System.out.println("Hello world Deepak Hello world");
				return ResponseEntity.ok(a.toString());
			}
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Trainer with Id: "+ad.getId()+" is not present");
		}
		 return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cohort with Id: "+ad.getCohortCode()+" is not present");
	}


	public boolean validatecohort(String cid) {
		if(cd.existsById(cid) == true) {
			return true;
		}
		return false;
		
	}
	
	
	public List<String> getCohorts(String hrId) {
		List<String> chts=new ArrayList<String>();
		List<CohortDTO> clist=cd.findByHrId(hrId);
		for(CohortDTO chd:clist) {
			chts.add(chd.getCohortCode());
		}
		return chts;
	}


	public boolean validatetrainer(PK id) {
		// TODO Auto-generated method stub
		
		if(adao.existsById(id) == true) {
			return true;
		}
		return false;
	}
	
}
