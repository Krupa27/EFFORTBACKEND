package com.trainer_management.hr_service.service;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.trainer_management.hr_service.Feigns.TrainerFeign;
import com.trainer_management.hr_service.model.Allocation;
import com.trainer_management.hr_service.model.AllocationDTO;
import com.trainer_management.hr_service.model.CohortDTO;
import com.trainer_management.hr_service.model.PK;
import com.trainer_management.hr_service.repository.AllocationDAO;
import com.trainer_management.hr_service.repository.CohortDAO;

@Service
public class CohortService {
	private CohortDAO cd;
	private AllocationDAO adao;
	private TrainerFeign tf;
	
	public CohortService(CohortDAO cd, AllocationDAO adao, TrainerFeign tf) {
		super();
		this.cd = cd;
		this.adao=adao;
		this.tf=tf;
	}
	
	
	public ResponseEntity<String> addCohort(CohortDTO c){
		 cd.save(c);
		 return ResponseEntity.ok(c.toString());
	}
    public ResponseEntity<String> deleteCohort(String cohortCode){
    	Optional<CohortDTO>  optCoh=cd.findById(cohortCode);
    	if(optCoh==null) return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("cohort code is not avaliable");
    	CohortDTO c=optCoh.get();
    	cd.delete(c);
    	return ResponseEntity.ok("deleted successfully");
    	
    }
	public ResponseEntity<CohortDTO> searchCohort(String cohortCode) {
		Optional<CohortDTO>  optCoh=cd.findById(cohortCode);
		CohortDTO c=optCoh.orElse(new CohortDTO());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(c);
	}
	public ResponseEntity<String> allocate(AllocationDTO ad){
		
		System.out.println(ad.toString());
		if(cd.findById(ad.getCohortCode()).isPresent() ) {
			if(tf.findById(ad.getId())) {
				PK primaryKey=new PK(ad.getCohortCode(),ad.getId());
				Allocation a=new Allocation(primaryKey,ad.getAreaWork());
				adao.save(a);
				return ResponseEntity.ok(a.toString());
			}
			return ResponseEntity.ok("Trainer with given id is not present");
		}
		return ResponseEntity.ok("Cohort with given id is not present");
	}
	
}
