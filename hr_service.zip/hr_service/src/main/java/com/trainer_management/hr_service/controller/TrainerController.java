package com.trainer_management.hr_service.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;


import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainer_management.hr_service.Feigns.TrainerFeign;
import com.trainer_management.hr_service.model.Allocation;
import com.trainer_management.hr_service.model.TrainerDTO;
import com.trainer_management.hr_service.model.TrainerInfo;
import com.trainer_management.hr_service.model.joinedDTO;
import com.trainer_management.hr_service.repository.AllocationDAO;
import com.trainer_management.hr_service.service.TrainerService;
import com.trainer_management.hr_service.model.*;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@CrossOrigin("http://localhost:3000/")
public class TrainerController {
    private TrainerService ts;
    private TrainerFeign fs;
    AllocationDAO rob;
	public TrainerController(TrainerService ts,TrainerFeign fs,AllocationDAO rob) {
		this.rob = rob;
		this.fs = fs;
		this.ts=ts;	
	}
	@PostMapping("/addTrainer")
	public String addTrainer(@RequestBody TrainerInfo td) {
		return ts.registerTrainer(td);
	}
	
	@DeleteMapping("/deleteTrainer/{id}")
	public ResponseEntity<String> deleteTrainer(@PathVariable String id) {
		return ts.deleteTrainer(id);
	}
	
	@GetMapping("/searchTrainer/{id}")
	public ResponseEntity<String> searchTrainer(@PathVariable String id) {
		return ts.searchTrainer(id);
	}
	
	
	
	@GetMapping("/search")
    public ResponseEntity<List<TrainerInfo>> searchTrainers(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Integer minExp,
            @RequestParam(required = false) Integer maxExp,
            @RequestParam(required = false) String mappedType,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String gender,
            @RequestParam(required = false) List<String> skills   
    ){
		return ts.searchTrainers(name, minExp, maxExp, mappedType, role, gender, skills);
	}
	 @GetMapping("/download")
	    public ResponseEntity<byte[]> downloadTrainerSheet() {
	    	List<joinedDTO> trainers = fs.getXL();
	    	// Fetch trainer effort data
	        // Fetch allocation data
	    	System.out.println("came to download");
	    	System.out.println(trainers.toString());	
	        for(joinedDTO ob:trainers) {
	        	String cc = ob.getCohortCode();
	        	PK pk = new PK(ob.getCohortCode(),ob.getTrainerID());
	        	
	        	System.out.println(ob.toString());		
	        	Optional<Allocation> opt = rob.findById(pk);
	        	if(opt.isPresent()) {
	        		ob.setAreaofWork(opt.get().getAreaWork());
	        	}
	        }
	        
	        
	        
	        
	        

	        try (Workbook workbook = new XSSFWorkbook()) {
	            Sheet sheet = workbook.createSheet("Trainers");

	            // Create header row
	            Row headerRow = sheet.createRow(0);
	            String[] headers = {
	                "Cohort Code", "Skill", "Mapped Trainer Type", "Trainer ID",
	                "Trainer Role", "Mode of Connection", "Virtual Connect Reason",
	                "Area of Work", "Effort (Hrs)", "Date"
	            };

	            for (int i = 0; i < headers.length; i++) {
	                headerRow.createCell(i).setCellValue(headers[i]);
	            }

	            // Populate trainer data
	            int rowNum = 1;
	            for (joinedDTO trainer : trainers) {
	            	System.out.println(trainer);
	                Row row = sheet.createRow(rowNum++);
	                row.createCell(0).setCellValue(trainer.getCohortCode());
	                row.createCell(1).setCellValue(String.join(", ", trainer.getSkill()));
	                row.createCell(2).setCellValue(trainer.getMappedTrainerType());
	                row.createCell(3).setCellValue(trainer.getTrainerID());
	                row.createCell(4).setCellValue(trainer.getTrainerRole());
	                row.createCell(5).setCellValue(trainer.getMode());
	                row.createCell(6).setCellValue(trainer.getReason());
	                row.createCell(7).setCellValue(trainer.getAreaofWork());
	                row.createCell(8).setCellValue(trainer.getEffortHrs());
	                row.createCell(9).setCellValue(trainer.getDate());
	            }

	            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	            workbook.write(byteArrayOutputStream);

	            // Prepare response headers for download
	            HttpHeaders headersMap = new HttpHeaders();
	            headersMap.set("Content-Disposition", "attachment; filename=TrainerData.xlsx");
	            headersMap.set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

	            return new ResponseEntity<>(byteArrayOutputStream.toByteArray(), headersMap, HttpStatus.OK);
	        } catch (IOException e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	        }
	    }
	
	
}
