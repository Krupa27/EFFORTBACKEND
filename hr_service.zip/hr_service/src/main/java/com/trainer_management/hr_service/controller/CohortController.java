package com.trainer_management.hr_service.controller;


import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trainer_management.hr_service.model.AllocationDTO;
import com.trainer_management.hr_service.model.CohortDTO;
import com.trainer_management.hr_service.model.PK;
import com.trainer_management.hr_service.service.CohortService;

@RestController
@CrossOrigin("http://localhost:3000/")

public class CohortController {
    
	CohortService cs;
	public CohortController(CohortService cs) {
		this.cs=cs;
	}

   @RequestMapping("/")
   public String hello() {
	   return "hello Deepak";
   }
   
   @PostMapping("/add-cohort")
   public ResponseEntity<String> addCohort(@RequestBody CohortDTO c){
	   return cs.addCohort(c);
   }
   
   @DeleteMapping("/delete-cohort/{cohortCode}")
   public ResponseEntity<String> deleteCohort(@PathVariable String cohortCode ){
	   return cs.deleteCohort(cohortCode);
   }
   
   @GetMapping("/search-cohort/{cohortCode}")
   public ResponseEntity<CohortDTO> searchCohort(@PathVariable String cohortCode ){
	   return cs.searchCohort(cohortCode);
   }
   
   @PostMapping("/allocate")
   public ResponseEntity<String> allocate(@RequestBody AllocationDTO ad){
	   return cs.allocate(ad);
   }
   
   @PostMapping("/validateCohort")
   public boolean validate(@RequestBody String cid) {
	   return cs.validatecohort(cid);
   }
   
   
   @GetMapping("/getCohorts/{hrId}")
   public List<String> getCohorts(@PathVariable String hrId){
	   return cs.getCohorts(hrId);
   }
   

   
   @PostMapping("/validateTrainer")
   public boolean validateTr(@RequestParam String id,@RequestParam String cid) {
	   
	   PK ob = new PK(cid,id); 
	   return cs.validatetrainer(ob);
	   
   }
   
   
}
