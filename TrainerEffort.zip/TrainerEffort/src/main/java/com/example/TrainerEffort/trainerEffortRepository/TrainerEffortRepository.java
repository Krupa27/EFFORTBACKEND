package com.example.TrainerEffort.trainerEffortRepository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TrainerEffort.effortDAO.Info;
import com.example.TrainerEffort.effortDAO.effortDAO;

public interface TrainerEffortRepository extends JpaRepository<effortDAO, Info> {

}
