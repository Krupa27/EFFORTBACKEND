package com.example.TrainerEffort.effortDAO;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Embeddable;

@Embeddable
public class Info implements Serializable {
	
	
	@JsonProperty("iD")
	private String ID;
	private String CohortCode;
	private String date;

	
	public Info(){}
	
	
	
	



	public String getDate() {
		return date;
	}







	public void setDate(String date) {
		this.date = date;
	}







	public String getID() {
		return ID;
	}



	public void setID(String iD) {
		this.ID = iD;
	}



	public String getCohortCode() {
		return CohortCode;
	}



	public void setCohortCode(String cohortCode) {
		CohortCode = cohortCode;
	}







	public Info(String iD, String cohortCode, String date) {
		super();
		ID = iD;
		CohortCode = cohortCode;
		this.date = date;
	}







	@Override
	public int hashCode() {
		return Objects.hash(CohortCode, ID, date);
	}







	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Info other = (Info) obj;
		return Objects.equals(CohortCode, other.CohortCode) && Objects.equals(ID, other.ID)
				&& Objects.equals(date, other.date);
	}







	@Override
	public String toString() {
		return "Info [ID=" + ID + ", CohortCode=" + CohortCode + ", date=" + date + "]";
	}


	





	



	
	
	
	
	
	

}
