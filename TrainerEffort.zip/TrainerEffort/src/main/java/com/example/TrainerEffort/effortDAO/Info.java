package com.example.TrainerEffort.effortDAO;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Embeddable;

@Embeddable
public class Info implements Serializable {
	
	
	@JsonProperty("iD")
	private String ID;
	private String CohortCode;
	
	public Info(){}
	
	
	
	public String getID() {
		return ID;
	}



	public void setID(String iD) {
		this.ID = iD;
	}



	public String getCohortCode() {
		return CohortCode;
	}



	public void setCohortCode(String cohortCode) {
		CohortCode = cohortCode;
	}



	@Override
	public int hashCode() {
		return Objects.hash(CohortCode, ID);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Info other = (Info) obj;
		return Objects.equals(CohortCode, other.CohortCode) && Objects.equals(ID, other.ID);
	}





	public Info(String iD, String cohortCode) {
		super();
		ID = iD;
		CohortCode = cohortCode;
	}





	@Override
	public String toString() {
		return "Info [ID=" + ID + ", CohortCode=" + CohortCode + "]";
	}
	
	
	
	
	

}
