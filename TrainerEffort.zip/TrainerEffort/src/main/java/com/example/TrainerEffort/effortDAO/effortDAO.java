package com.example.TrainerEffort.effortDAO;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity

public class effortDAO {
	
	@EmbeddedId
	@AttributeOverrides({
		@AttributeOverride(name="ID", column= @Column(name="ID", length=50)),
		@AttributeOverride(name="CohortCode", column= @Column(name="cohort_code", length=50))
		
	})
	private Info info;
	public Info getInfo() {
		return info;
	}
	public void setInfo(Info info) {
		this.info = info;
	}
	private String Mode;
	private String Reason;
	private String EffortHours;
	private String Date;
	private String Topic;
	private String Highlights;
	
	public String getMode() {
		return Mode;
	}
	public void setMode(String mode) {
		Mode = mode;
	}
	public String getReason() {
		return Reason;
	}
	public void setReason(String reason) {
		Reason = reason;
	}
	public String getEffortHours() {
		return EffortHours;
	}
	public void setEffortHours(String effortHours) {
		EffortHours = effortHours;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getTopic() {
		return Topic;
	}
	public void setTopic(String topic) {
		Topic = topic;
	}
	public String getHighlights() {
		return Highlights;
	}
	public void setHighlights(String highlights) {
		Highlights = highlights;
	}
	
	
	public effortDAO(Info info, String mode, String reason, String effortHours, String date, String topic,
			String highlights) {
		super();
		this.info = info;
		this.Mode = mode;
		this.Reason = reason;
		this.EffortHours = effortHours;
		this.Date = date;
		this.Topic = topic;
		this.Highlights = highlights;
	}
	

	public effortDAO() {

	}
	@Override
	public String toString() {
		return "effortDAO [info=" + info + ", Mode=" + Mode + ", Reason=" + Reason + ", EffortHours=" + EffortHours
				+ ", Date=" + Date + ", Topic=" + Topic + ", Highlights=" + Highlights + "]";
	}

	
	

}
