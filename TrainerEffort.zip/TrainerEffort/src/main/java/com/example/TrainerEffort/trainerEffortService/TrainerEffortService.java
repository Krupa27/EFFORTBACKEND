package com.example.TrainerEffort.trainerEffortService;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.TrainerEffort.Specification.TrainerSpecification;
import com.example.TrainerEffort.effortDAO.Info;
import com.example.TrainerEffort.effortDAO.Joined;
import com.example.TrainerEffort.effortDAO.effortDAO;
import com.example.TrainerEffort.effortDAO.TrainerInfo;
import com.example.TrainerEffort.trainerEffortRepository.TrainerEffortRepository;
import com.example.TrainerEffort.trainerEffortRepository.updateRepository;
import com.example.TrainerEffort.trainerEffortcontroller.password;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@Service
public class TrainerEffortService {
	

	
	@Autowired
	TrainerEffortRepository rob;
	@Autowired
	updateRepository rob2;

	public List<Joined> downloadXL() {
    	List<Joined> effortList=new ArrayList();
		List<effortDAO> effort=rob.findAll();
		for(effortDAO eff:effort) {
			String id=eff.getInfo().getID();
			Optional<TrainerInfo> op=rob2.findById(id);
			if(op.isPresent()) {
				TrainerInfo tf=op.get();
				Joined j=new Joined(eff.getInfo().getCohortCode(),tf.getSkills().toString(), tf.getMappedType(), id,tf.getRole(),
						eff.getMode(), eff.getReason(), "hr",eff.getEffortHours(),eff.getDate() );
				effortList.add(j);
			}
			
		}
		//List<TrainerInfo> trainInf=rob2.findAll();
//		for(effortDAO eff:effort) {
//			String id=eff.getInfo().getID();
//			for(TrainerInfo tf:trainInf) {
//				if(tf.getId().equalsIgnoreCase(id)) {
//					Joined j=new Joined(eff.getInfo().getCohortCode(),tf.getSkills().toString(), tf.getMappedType(), id,tf.getRole(),
//							eff.getMode(), eff.getReason(), "hr",eff.getEffortHours(),eff.getDate() );
//					effortList.add(j);
//				}
//			}
//			
//			
//		}
		return effortList;
		
	}
	public String geteffort(effortDAO incomingEffortData) {
		
		
		Info infoId = incomingEffortData.getInfo();
		System.out.println(incomingEffortData);
		System.out.println(infoId);
        if (infoId == null || infoId.getID() == null || infoId.getID().isEmpty() ||
            infoId.getCohortCode() == null || infoId.getCohortCode().isEmpty()) {
            return "Error: Trainer ID and Cohort ID must be provided and not empty.";
        }

        Optional<effortDAO> existingTrainerEffortOptional = rob.findById(infoId);

        if (existingTrainerEffortOptional.isPresent()) {
            effortDAO existingTrainerEffort = existingTrainerEffortOptional.get();

            if (incomingEffortData.getMode() != null) {
                existingTrainerEffort.setMode(incomingEffortData.getMode());
            }
            if (incomingEffortData.getReason() != null) {
                existingTrainerEffort.setReason(incomingEffortData.getReason());
            }
            if (incomingEffortData.getEffortHours() != null) {
                existingTrainerEffort.setEffortHours(incomingEffortData.getEffortHours());
            }
            if (incomingEffortData.getDate() != null) {
                existingTrainerEffort.setDate(incomingEffortData.getDate());
            }
            if (incomingEffortData.getTopic() != null) {
                existingTrainerEffort.setTopic(incomingEffortData.getTopic());
            }
            if (incomingEffortData.getHighlights() != null) {
                existingTrainerEffort.setHighlights(incomingEffortData.getHighlights());
            }

            rob.save(existingTrainerEffort);
            return "Trainer effort updated successfully for ID: " + infoId.getID() + ", Cohort ID: " + infoId.getCohortCode();

        } else {

        	 effortDAO newTrainerEffort = new effortDAO();
             newTrainerEffort.setInfo(infoId);
             newTrainerEffort.setMode(incomingEffortData.getMode());
             newTrainerEffort.setReason(incomingEffortData.getReason());
             newTrainerEffort.setEffortHours(incomingEffortData.getEffortHours());
             newTrainerEffort.setDate(incomingEffortData.getDate());
             newTrainerEffort.setTopic(incomingEffortData.getTopic());
             newTrainerEffort.setHighlights(incomingEffortData.getHighlights());
             
             rob.save(newTrainerEffort); 
             return "New trainer effort record created successfully for ID: " + infoId.getID() + ", Cohort ID: " + infoId.getCohortCode();
        }
    
    }
	

	
	
	
	public boolean findById(String id) {
		return rob2.findById(id).isPresent();
	}
	public String addTrainer(TrainerInfo td) {
		rob2.save(td);
		return td.toString();
	}
	
	public List<TrainerInfo> findAll() {
		// TODO Auto-generated method stub
		return rob2.findAll();
		
	}
	
	public String deleteTrainer(String id) {
		Optional<TrainerInfo> otf=rob2.findById(id);
		if(otf.isPresent()) {
			rob2.deleteById(id);
		  return id+" deleted Trainer Successfully";
		}
		return id+" not found";
	}
	
	public String searchTrainer(String id) {
		Optional<TrainerInfo> otf=rob2.findById(id);
		if(otf.isPresent()) {
		  return otf.get().toString();
		}
		return id+" is not present";
		
	}
	
	public List<TrainerInfo> searchTrainers(String name, Integer minExp, Integer maxExp,
            String mappedType, String role, String gender,
            List<String> skills) {
	
		Specification<TrainerInfo> spec = TrainerSpecification.hasName(name)
		.and(TrainerSpecification.hasExperienceGreaterThan(minExp))
		.and(TrainerSpecification.hasExperienceLessThan(maxExp))
		.and(TrainerSpecification.hasMappedType(mappedType))
		.and(TrainerSpecification.hasRole(role))
		.and(TrainerSpecification.hasGender(gender))
		.and(TrainerSpecification.hasSkills(skills));
		
		return rob2.findAll(spec);
	}

	
	
	public String updateTrainerInfo(TrainerInfo updatedTrainerData) {
        //(null checks for critical fields)
        if (updatedTrainerData.getId() == null) {
            return "Error: Trainer ID must be provided for update.";
        }
        if (updatedTrainerData.getName() == null || updatedTrainerData.getName().trim().isEmpty()) {
            return "Trainer name cannot be empty.";
        }

        Optional<TrainerInfo> existingTrainerOptional = rob2.findById(updatedTrainerData.getId());

        if (existingTrainerOptional.isPresent()) {
            TrainerInfo existingTrainer = existingTrainerOptional.get();

            // Using Objects.equals for null-safe comparison
//            if (!Objects.equals(updatedTrainerData.getGender(), existingTrainer.getGender())) {
//                return "Sorry!, Gender cannot be updated";
//            }
//
//            if (!Objects.equals(existingTrainer.getEmail(), updatedTrainerData.getEmail())) {
//                return "Sorry!, Email cannot be updated";
//            }


            existingTrainer.setName(updatedTrainerData.getName());
            existingTrainer.setPhoneNumber(updatedTrainerData.getPhoneNumber());
            existingTrainer.setMappedType(updatedTrainerData.getMappedType());
            existingTrainer.setRole(updatedTrainerData.getRole());

//            existingTrainer.setPassword(updatedTrainerData.getPassword()); 

            // Save updated trainer
            rob2.save(existingTrainer);
            return "Trainer info updated successfully.";

        } else {
            return "Error: Trainer with ID " + updatedTrainerData.getId() + " not found.";
        }
	}
	
	
	
	@Autowired
	private RestTemplate restTemplate; // Ensure this is configured in your project
	
	
	public String resetTrainerPassword(String trainerID, String newPassword) {
	    if (trainerID == null || trainerID.trim().isEmpty() || newPassword == null || newPassword.trim().isEmpty()) {
	        return "Error: Trainer ID and new password must be provided.";
	    }

	    Optional<TrainerInfo> existingTrainerOptional = rob2.findById(trainerID);

	    if (existingTrainerOptional.isPresent()) {
	        TrainerInfo existingTrainer = existingTrainerOptional.get();

	        // Encrypt the new password
	        existingTrainer.setPassword(passwordEncoder.encode(newPassword));
	        
	        // Save updated trainer password
	        rob2.save(existingTrainer);
	        
	        boolean jwtSaveSuccess = updateTrainerInJwtService(trainerID,newPassword);

		    if (!jwtSaveSuccess) {
		        return "Trainer registered in TrainerInfo table, but failed in JWT service.";
		    }

	        // Send email notification
	        sendPassword1(existingTrainer.getEmail(), newPassword);

	        return "Password reset successfully! A confirmation email has been sent.";
	    } else {
	        return "Error: Trainer with ID " + trainerID + " not found.";
	    }
	}

	
//	public String resetTrainerPassword(String trainerId, String newPassword) {
//	    String jwtServiceUrl = "http://localhost:8082/generateHashPassword";
//
//	    // Get valid JWT token (Replace with actual authentication logic)
//	    
//	    String token = getJwtToken();
//
//	    if (token == null || token.isEmpty()) {
//	        return "Error: Could not retrieve JWT token for authentication.";
//	    }
//
//	    // Setup headers
//	    HttpHeaders headers = new HttpHeaders();
//	    headers.set("Authorization", "Bearer " + token);
//	    headers.set("Content-Type", "application/json");
//
//	    // Prepare request body
//	    Map<String, String> requestBody = new HashMap<>();
//	    requestBody.put("password", newPassword);
//
//	    HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);
//	    
//	    RestTemplate restTemplate = new RestTemplate();
//	    ResponseEntity<String> response = restTemplate.exchange(jwtServiceUrl, HttpMethod.POST, requestEntity, String.class);
//
//	    if (response.getStatusCode().is2xxSuccessful()) {
//	        String hashedPassword = response.getBody();
//	        
//	        // Update trainer password in database
//	        Optional<TrainerInfo> trainerOpt = rob2.findById(trainerId);
//	        if (trainerOpt.isPresent()) {
//	            TrainerInfo trainer = trainerOpt.get();
//	            trainer.setPassword(hashedPassword);
//	            rob2.save(trainer);
//
//	            
//	            return "Password updated successfully!";
//	        } else {
//	            return "Error: Trainer with ID " + trainerId + " not found.";
//	        }
//	        
//	    } else {
//	        return "Error fetching hashed password. Status code: " + response.getStatusCode();
//	    }
//	}
	

	
	
	
//	public String getJwtToken() {
//	    String jwtLoginUrl = "http://localhost:8082/login"; // JWT service login endpoint
//
//	    Map<String, String> loginPayload = new HashMap<>();
//	    loginPayload.put("username", "2397832");
//	    loginPayload.put("password", "%vNxPv80Io"); // Replace with actual credentials
//
//	    HttpHeaders headers = new HttpHeaders();
//	    headers.set("Content-Type", "application/json");
//
//	    HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(loginPayload, headers);
//	    
//	    RestTemplate restTemplate = new RestTemplate();
//	    ResponseEntity<String> response = restTemplate.exchange(jwtLoginUrl, HttpMethod.POST, requestEntity, String.class);
//	    
//	    if (response.getStatusCode().is2xxSuccessful()) {
//	        return response.getBody(); // JWT token
//	    } else {
//	        throw new RuntimeException("Failed to retrieve JWT token: " + response.getStatusCode());
//	    }
//	}
	
	private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    private static final int PASSWORD_LENGTH = 10;

    public static String generatePassword() {
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder(PASSWORD_LENGTH);
        for (int i = 0; i < PASSWORD_LENGTH; i++) {
            password.append(CHARACTERS.charAt(random.nextInt(CHARACTERS.length())));
        }
        return password.toString();
    }
	
	
	

    @Autowired
    private JavaMailSender mailSender;
    
    public void sendPassword1(String email, String password) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Trainer Password Updated");
        message.setText("Congrats! Your password for Trainer login has been updated successfully" +
                        "\nYour NewPassword is "+password);
        mailSender.send(message);
    }

    public void sendPassword(String email, String password) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your Trainer Account Credentials");
        message.setText("Welcome! Your temporary password is: " + password +
                        "\nPlease reset it upon first login.");
        mailSender.send(message);
    }
	

	@Autowired
	password pob;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	public String registerTrainer(TrainerInfo trainerInfo) {
	    String tempPassword = generatePassword();
	    
	    trainerInfo.setPassword(passwordEncoder.encode(tempPassword)); // ✅ Correct
	    rob2.save(trainerInfo);
	    
	    boolean jwtSaveSuccess = saveTrainerInJwtService(trainerInfo,tempPassword);

	    if (!jwtSaveSuccess) {
	        return "Trainer registered in TrainerInfo table, but failed in JWT service.";
	    }
	    // Send email with temporary password
	    sendPassword(trainerInfo.getEmail(), tempPassword);

	    return "Trainer registered successfully! Temporary password sent.";
	}
	
	
	
	public boolean saveTrainerInJwtService(TrainerInfo trainerInfo,String tempPass) {
	    String jwtServiceUrl = "http://localhost:8082/register"; // Change to actual JWT service URL

	    HttpHeaders headers = new HttpHeaders();
	    headers.set("Content-Type", "application/json");

	    Map<String, Object> requestBody = new HashMap<>();
	    requestBody.put("username", trainerInfo.getId());  // Use trainer ID as username
	    requestBody.put("password",tempPass); // Send unhashed password, let JWT service hash it
	    requestBody.put("role", trainerInfo.getRole()); 

	    HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);
	    
	    ResponseEntity<String> response = restTemplate.exchange(jwtServiceUrl, HttpMethod.POST, requestEntity, String.class);

	    return response.getStatusCode().is2xxSuccessful();
	}
	
	public boolean updateTrainerInJwtService(String trainerID, String newPassword) {
	    String jwtServiceUrl = "http://localhost:8082/resetPassword"; // Change to actual JWT service URL

	    HttpHeaders headers = new HttpHeaders();
	    headers.set("Content-Type", "application/json");

	    Map<String, Object> requestBody = new HashMap<>();
	    requestBody.put("username", trainerID);
	    requestBody.put("password", newPassword); // Send unhashed password

	    HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

	    ResponseEntity<String> response = restTemplate.exchange(jwtServiceUrl, HttpMethod.POST, requestEntity, String.class);

	    return response.getStatusCode().is2xxSuccessful();
	}

	

	

	



	

	
	
	
	
	
	
	

	
	
	
}