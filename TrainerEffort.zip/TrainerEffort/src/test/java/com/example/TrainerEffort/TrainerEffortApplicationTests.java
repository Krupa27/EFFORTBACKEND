package com.example.TrainerEffort;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainerEffortApplicationTests {

	@Test
	void contextLoads() {
	}

}
